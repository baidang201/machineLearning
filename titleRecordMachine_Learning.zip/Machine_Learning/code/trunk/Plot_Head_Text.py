import os
import os.path
import xml.dom.minidom
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

rootdirlist = ["C:/Users/Administrator/Desktop/fastdata/Train/76/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/77/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/78/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/796/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/981/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1145/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1147/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1336/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1338/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1330/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1317/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1308/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1172/ConvertData"]

feature_arr = []

for rootdir in rootdirlist:
    files = os.listdir(rootdir)
    for index in range(len(files)):
        files[index] = (rootdir + "/") + files[index]
    
    total_arr = []
    averagesize = 0.0
    averagespace = 0.0
    totalwordnumber = 0
    totalspacenumber = 0
    
    for singlefile in files:
        dom = xml.dom.minidom.parse(singlefile)
        root = dom.documentElement
        page = root.getElementsByTagName('page')
        blocks = page[0].getElementsByTagName('block')
        for block in blocks:
            arr = []
            arr.append(block.getAttribute('id'))
            arr.append(block.getAttribute('blockType'))
            arr.append(int(block.getAttribute('wordNumber')))
            arr.append(float(block.getAttribute('widthRatio')))
            arr.append(float(block.getAttribute('heightRatio')))
            arr.append(float(block.getAttribute('areaRatio')))
            arr.append(float(block.getAttribute('fontAverageWidth')))
            arr.append(float(block.getAttribute('fontAverageHeight')))
            arr.append(float(block.getAttribute('fontAverageSize')))
            arr.append(float(block.getAttribute('fontAverageSpace')))
            arr.append(int(block.getAttribute('wordSpaceNumber')))
            arr.append(block.getAttribute('indexing'))
            total_arr.append(arr)
            averagesize += arr[2] * arr[8]
            totalwordnumber += arr[2]
            averagespace += arr[9] * arr[10]
            totalspacenumber += arr[10]
       
    averagesize = averagesize / totalwordnumber 
    averagespace = averagespace / totalspacenumber
    
    for singleblockattribute in total_arr:
        arr = []
        arr.append(singleblockattribute[8]/averagesize)
        arr.append(singleblockattribute[5])
        arr.append(singleblockattribute[9]/averagespace)
        arr.append(singleblockattribute[11])
        feature_arr.append(arr)
    
print "total sample is " + str(len(feature_arr))

feature_head = []
feature_text = []

for feature in feature_arr:
    if "heading" in feature[3]:
        feature.pop()
        feature_head.append(feature)
    else:
        feature.pop()
        feature_text.append(feature)

feature_head = np.array(feature_head)
feature_text = np.array(feature_text)

#三维散点图，区分标题和文本
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.scatter(feature_head[:,0], feature_head[:,1], feature_head[:,2],color='red', marker='o', label='heading')
ax.scatter(feature_text[:,0], feature_text[:,1], feature_text[:,2],color='blue', marker='x', label='text')
ax.set_xlabel('Font scale')
ax.set_ylabel('block area scale')
ax.set_zlabel('space scale')
#把说明放在左上角，具体请参考官方文档
ax.legend(loc=2)
