# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 17:05:26 2017

@author: hdx
"""

import os
import os.path
import xml.dom.minidom
import numpy as np

traindirlist = ["C:/Users/Administrator/Desktop/fastdata/Train/76/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/77/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/78/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/796/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/981/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1145/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1147/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1336/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1338/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1330/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1317/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1308/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1364/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1172/ConvertData"]

testdirlist = ["C:/Users/Administrator/Desktop/fastdata/Train/1364/ConvertData"]

"""**************************************提取特征函数*********************************************"""
def GetFeature(dirlist):
    feature_arr = list([])
    for rootdir in dirlist:
        files = os.listdir(rootdir)
        for index in range(len(files)):
            files[index] = (rootdir + "/") + files[index]
        
        total_arr = []
        averagesize = 0.0
        averagespace = 0.0
        totalwordnumber = 0
        totalspacenumber = 0
        
        for singlefile in files:
            dom = xml.dom.minidom.parse(singlefile)
            root = dom.documentElement
            page = root.getElementsByTagName('page')
            blocks = page[0].getElementsByTagName('block')
            for block in blocks:
                arr = []
                arr.append(block.getAttribute('id'))
                arr.append(block.getAttribute('blockType'))
                arr.append(int(block.getAttribute('wordNumber')))
                arr.append(float(block.getAttribute('widthRatio')))
                arr.append(float(block.getAttribute('heightRatio')))
                arr.append(float(block.getAttribute('areaRatio')))
                arr.append(float(block.getAttribute('fontAverageWidth')))
                arr.append(float(block.getAttribute('fontAverageHeight')))
                arr.append(float(block.getAttribute('fontAverageSize')))
                arr.append(float(block.getAttribute('fontAverageSpace')))
                arr.append(int(block.getAttribute('wordSpaceNumber')))
                arr.append(block.getAttribute('indexing'))
                total_arr.append(arr)
                averagesize += arr[2] * arr[8]
                totalwordnumber += arr[2]
                averagespace += arr[9] * arr[10]
                totalspacenumber += arr[10]
           
        averagesize = averagesize / totalwordnumber 
        averagespace = averagespace / totalspacenumber
        
        for singleblockattribute in total_arr:
            arr = []
            arr.append(singleblockattribute[8]/averagesize)
            arr.append(singleblockattribute[5])
            arr.append(singleblockattribute[9]/averagespace)
            arr.append(singleblockattribute[11])
#            arr.append(singleblockattribute[3])
#            arr.append(singleblockattribute[4])
            feature_arr.append(arr)
    
    feature_target = list([])
    
    """1为标题，0为正文"""
    for feature in feature_arr:
        if "heading" in feature[3]:
            feature_target.append(1)
        else:
            feature_target.append(0)
        feature.pop(3)
        
    feature_arr = np.array(feature_arr)
    feature_target = np.array(feature_target)
    return feature_arr,feature_target
"""***************************************************************************************"""

train_feature_arr,train_feature_target = GetFeature(traindirlist)
test_feature_arr,test_feature_target = GetFeature(testdirlist)
print "total train sample is " + str(len(train_feature_arr))
print "total test sample is " + str(len(test_feature_arr))


"""*************************Logistic Regression Classifier********************************"""
X_train = train_feature_arr
X_test = test_feature_arr
y_train = train_feature_target
y_test = test_feature_target

from sklearn.preprocessing import StandardScaler

sc = StandardScaler()
sc.fit(X_train)
#标准化数据
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)

"""
from sklearn.linear_model import LogisticRegression
lr = LogisticRegression(C=10.0, random_state=0)
lr.fit(X_train_std, y_train)
y_pred = lr.predict(X_test_std)
"""

from sklearn.ensemble import RandomForestClassifier
RFclf = RandomForestClassifier(n_estimators = 100) 
RFclf.fit(X_train_std, y_train)
y_pred = RFclf.predict(X_test_std)

from sklearn.metrics import accuracy_score
#准确率
accuracy_rate = accuracy_score(y_test, y_pred)
print "accuracy rate is " + str(accuracy_rate)

#print list(y_test)
#print list(y_pred)
    


