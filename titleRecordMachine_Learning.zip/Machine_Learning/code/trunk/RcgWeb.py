# -*- coding: utf-8 -*-
"""
Created on Wed Mar 20 14:17:23 2017

@author: hdx
"""

import BaseHTTPServer
import titlercg
import json
"""
traindirlist = ["C:/Users/Administrator/Desktop/fastdata/Train/76/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/77/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/78/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/796/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/981/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1145/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1147/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1336/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1338/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1330/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1317/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1308/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1172/ConvertData"]

testdirlist = ["C:/Users/Administrator/Desktop/fastdata/Train/1172/ConvertData"]
"""

"""
/train接口通过post方式将训练数据所在路径发到标题识别进程，数据格式为{path:["path1","path2",...,"pathn"]}
/predict接口通过post方式将测试数据所在路径发送到标题识别进程，数据格式同上
"""

class RequestHandler(BaseHTTPServer.BaseHTTPRequestHandler):
    def do_POST(self):
        print self.path
        if self.path == '/train':
            data_json = self.rfile.read(int(self.headers['Content-Length']))
            data_dict = json.loads(data_json)
            data_list = data_dict['path']
            train_feature_list,train_resluts_list = titlercg.GetFeature(data_list)
            titlercg.TrainClassifier(train_feature_list,train_resluts_list,'LRModel.pkl','std.pkl')
            self.send_response(200)
            #self.send_header("Content-Type", "text/html")
            msg = {"status":0,"msg":"success"}
            msg = json.dumps(msg)
            self.send_header("Content-Length", len(msg))
            self.end_headers()
            self.wfile.write(msg)
        elif self.path == '/predict':
            data_json = self.rfile.read(int(self.headers['Content-Length']))
            data_dict = json.loads(data_json)
            data_list = data_dict['path']
            test_feature_list,test_resluts_list = titlercg.GetFeature(data_list)
            pathid_list = titlercg.GetPathidList(testdirlist)
            predict_resuls_list = titlercg.ClassifierPredict(test_feature_list,'LRModel.pkl','std.pkl')
            score = titlercg.GetAccuracyScore(test_resluts_list,predict_resuls_list)
            print score
            self.send_response(200)
            #self.send_header("Content-Type", "text/html")
            if titlercg.SavePredictedData(pathid_list,predict_resuls_list):
                msg = {"status":0,"msg":"success"}
                msg = json.dumps(msg)
                self.send_header("Content-Length", len(msg))
                self.end_headers()
                self.wfile.write(msg)
            else:
                msg = {"status":1,"msg":"error"}
                msg = json.dumps(msg)
                self.send_header("Content-Length", len(msg))
                self.end_headers()
                self.wfile.write(msg)
                
        
serverAddress = ('127.0.0.1', 10010)
server = BaseHTTPServer.HTTPServer(serverAddress, RequestHandler)
server.serve_forever()