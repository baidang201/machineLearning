# -*- coding: utf-8 -*-

import os
import os.path
import xml.dom.minidom
import numpy as np
import csv


"""**************************************提取特征函数*********************************************"""
def GetFeature(dirlist):
    """
    Parameters:
    ----------
    dirlist : filepath list
    """
    feature_arr = list([])
    for rootdir in dirlist:
        files = os.listdir(rootdir)
        for index in range(len(files)):
            files[index] = (rootdir + "/") + files[index]
        
        total_arr = []
        averagesize = 0.0
        averagespace = 0.0
        totalwordnumber = 0
        totalspacenumber = 0
        
        for singlefile in files:
            if not os.path.isfile(singlefile):
                continue
            dom = xml.dom.minidom.parse(singlefile)
            root = dom.documentElement
            page = root.getElementsByTagName('page')
            blocks = page[0].getElementsByTagName('block')
            for block in blocks:
                arr = []
                arr.append(block.getAttribute('id'))
                arr.append(block.getAttribute('blockType'))
                arr.append(int(block.getAttribute('wordNumber')))
                arr.append(float(block.getAttribute('widthRatio')))
                arr.append(float(block.getAttribute('heightRatio')))
                arr.append(float(block.getAttribute('areaRatio')))
                arr.append(float(block.getAttribute('fontAverageWidth')))
                arr.append(float(block.getAttribute('fontAverageHeight')))
                arr.append(float(block.getAttribute('fontAverageSize')))
                arr.append(float(block.getAttribute('fontAverageSpace')))
                arr.append(int(block.getAttribute('wordSpaceNumber')))
                arr.append(block.getAttribute('indexing'))
                total_arr.append(arr)
                averagesize += arr[2] * arr[8]
                totalwordnumber += arr[2]
                averagespace += arr[9] * arr[10]
                totalspacenumber += arr[10]
           
        averagesize = averagesize / totalwordnumber 
        averagespace = averagespace / totalspacenumber
        
        for singleblockattribute in total_arr:
            arr = []
            arr.append(singleblockattribute[8]/averagesize)
            arr.append(singleblockattribute[5])
            arr.append(singleblockattribute[9]/averagespace)
            arr.append(singleblockattribute[11])
            arr.append(singleblockattribute[3])
            arr.append(singleblockattribute[4])
            feature_arr.append(arr)
    
    feature_target = list([])
    
    """1为标题，0为正文"""
    for feature in feature_arr:
        if "heading1" in feature[3]:
            feature_target.append(11)
        elif "heading2" in feature[3]:
            feature_target.append(12)
        elif "heading3" in feature[3]:
            feature_target.append(13)
        elif "heading4" in feature[3]:
            feature_target.append(14)
        elif "heading5" in feature[3]:
            feature_target.append(15)
        elif "heading6" in feature[3]:
            feature_target.append(16)
        elif "text" in feature[3]:
            feature_target.append(0)
        elif "picturetitle" in feature[3]:
            feature_target.append(1)
        elif "picturenote" in feature[3]:
            feature_target.append(2)
        elif "tabletitle" in feature[3]:
            feature_target.append(3)
        elif "tablenote" in feature[3]:
            feature_target.append(4)
        elif "footnote" in feature[3]:
            feature_target.append(5)
        elif "endnote" in feature[3]:
            feature_target.append(6)
        elif "copyright" in feature[3]:
            feature_target.append(7)
        else:
            feature_target.append(99)
        feature.pop(3)
        
    feature_arr = np.array(feature_arr)
    feature_target = np.array(feature_target)
    return feature_arr,feature_target
"""***************************************************************************************"""

"""*************************Logistic Regression Classifier********************************"""
def TrainClassifier(train_feature_arr,train_feature_target,model_filename,std_filename):
    """
    Parameters:
    ----------
    train_feature_arr : feature list
    train_feature_target : feature list
    model_filename : model file name
    std_filename : standardized data file name
    """
    from sklearn.preprocessing import StandardScaler
    sc = StandardScaler()
    sc.fit(train_feature_arr)
    X_train_std = sc.transform(train_feature_arr)
    from sklearn.externals import joblib
#保存标准化数据对象
    joblib.dump(sc,std_filename)
    
    from sklearn.linear_model import LogisticRegression
    lr = LogisticRegression(C=10.0, random_state=0)
    lr.fit(X_train_std, train_feature_target)
#保存logistic回归模型
    joblib.dump(lr,model_filename)
    
"""***************************************************************************************"""

"""***********************************Predict*********************************************"""
def ClassifierPredict(test_feature_arr,model_filename,std_filename):
    """
    Parameters:
    ----------
    model_filename : model file name
    std_filename : standardized data file name
    """
    from sklearn.externals import joblib
#还原标准化数据对象
    sc = joblib.load(std_filename)
    X_test_std = sc.transform(test_feature_arr)
#还原logistic回归模型
    lr = joblib.load(model_filename)
    
    return lr.predict(X_test_std)
    
"""***************************************************************************************"""

"""***********************************get accuracy score**********************************"""
def GetAccuracyScore(test_results, predict_results):
    """
    Parameters:
    ----------
    test_results : known results list
    predict_results : predicted results list
    """
    from sklearn.metrics import accuracy_score
    #准确率
    accuracy_rate = accuracy_score(test_results, predict_results)
    return accuracy_rate
    
"""***************************************************************************************"""

"""*********************************Get pathid list***************************************"""
def GetPathidList(dirlist):
    """
    Parameters:
    ----------
    dirlist : filepath list
    """
    pathid_list = list([])
    for rootdir in dirlist:
        files = os.listdir(rootdir)
        for index in range(len(files)):
            files[index] = (rootdir + "/") + files[index]
        
        for singlefile in files:
            if not os.path.isfile(singlefile):
                continue
            dom = xml.dom.minidom.parse(singlefile)
            root = dom.documentElement
            page = root.getElementsByTagName('page')
            blocks = page[0].getElementsByTagName('block')
            for block in blocks:
                arr = []
                arr.append(block.getAttribute('id'))
                arr.append(singlefile)
                pathid_list.append(arr)
    return pathid_list
        
"""***************************************************************************************"""

"""*******************************Save predicted data in xml******************************"""
def SavePredictedData(pathid_list,result_list):
    """
    Parameters:
    ----------
    pathid_list : data path and id list
    result_list : result list
    """
    if len(pathid_list) != len(result_list):
        return False
    else:
        for i in range(len(pathid_list)):
            dataid = pathid_list[i][0]
            datapath_stu = os.path.split(pathid_list[i][1])
            datacontent = result_list[i]
            datapath = datapath_stu[0] + "/../PredictedData"
            if not os.path.exists(datapath):
                os.makedirs(datapath)   
            csvfile = file(datapath + '/data.csv', 'a')
            writer = csv.writer(csvfile)
            data = (dataid,datacontent)
            writer.writerow(data)
            csvfile.close()
        return True
    
"""***************************************************************************************"""