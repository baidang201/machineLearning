# -*- coding: utf-8 -*-
"""
Created on Wed Mar 15 14:17:23 2017

@author: hdx
"""
import titlercg

traindirlist = ["C:/Users/Administrator/Desktop/fastdata/Train/76/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/77/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/78/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/796/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/981/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1145/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1147/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1336/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1338/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1330/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1317/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1308/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1172/ConvertData"]

train_feature_list,train_resluts_list = titlercg.GetFeature(traindirlist)

#训练数据
titlercg.TrainClassifier(train_feature_list,train_resluts_list,'LRModel.pkl','std.pkl')
