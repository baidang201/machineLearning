# -*- coding: utf-8 -*-
"""
Created on Wed Mar 20 14:17:23 2017

@author: hdx
"""
import titlercg

testdirlist = ["C:/Users/Administrator/Desktop/fastdata/Train/1330/ConvertData"]

test_feature_list,test_resluts_list = titlercg.GetFeature(testdirlist)
pathid_list = titlercg.GetPathidList(testdirlist)

#预测数据
predict_resuls_list = titlercg.ClassifierPredict(test_feature_list,'LRModel.pkl','std.pkl')

#对比测试数据的真实结果
score = titlercg.GetAccuracyScore(test_resluts_list,predict_resuls_list)

print "score is " + str(score)
print "测试数据总样本数为" + str(len(test_resluts_list))
print "预测错误的数据个数为" + str(int((1-score)*len(test_resluts_list)))

if titlercg.SavePredictedData(pathid_list,predict_resuls_list):
    print "保存数据成功"
else:
    print "保存数据失败"