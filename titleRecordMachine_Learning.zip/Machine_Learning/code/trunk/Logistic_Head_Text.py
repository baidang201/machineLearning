# -*- coding: utf-8 -*-
"""
Created on Wed Mar 15 14:17:23 2017

@author: hdx
"""
import multititlercg as rcg

traindirlist = ["C:/Users/Administrator/Desktop/fastdata/Train/76/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/77/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/78/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/796/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/981/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1145/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1147/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1336/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1338/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1330/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1317/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1308/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1364/ConvertData",
                  "C:/Users/Administrator/Desktop/fastdata/Train/1172/ConvertData"]

testdirlist = ["C:/Users/Administrator/Desktop/fastdata/Train/1364/ConvertData"]

train_feature_list,train_resluts_list = rcg.GetFeature(traindirlist)
test_feature_list,test_resluts_list = rcg.GetFeature(testdirlist)
pathid_list = rcg.GetPathidList(testdirlist)

#训练数据
rcg.TrainClassifier(train_feature_list,train_resluts_list,'LRModel.pkl','std.pkl')

#预测数据
predict_resuls_list = rcg.ClassifierPredict(test_feature_list,'LRModel.pkl','std.pkl')

#对比测试数据的真实结果
score = rcg.GetAccuracyScore(test_resluts_list,predict_resuls_list)

print "score is " + str(score)
print "测试数据总样本数为" + str(len(test_resluts_list))
print "预测错误的数据个数为" + str(int((1-score)*len(test_resluts_list)))
print test_resluts_list
print predict_resuls_list

if rcg.SavePredictedData(pathid_list,predict_resuls_list):
    print "保存数据成功"
else:
    print "保存数据失败"
